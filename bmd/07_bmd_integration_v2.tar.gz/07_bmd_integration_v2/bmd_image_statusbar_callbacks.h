#ifndef _bmd_image_statusbar_callbacks_
#define _bmd_image_statusbar_callbacks_

void bmd_prev_clicked(GtkWidget *widget, gpointer data);
void bmd_next_clicked(GtkWidget *widget, gpointer data);

#endif