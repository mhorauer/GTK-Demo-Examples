#ifndef _image_statusbar_callbacks_
#define _image_statusbar_callbacks_

void bmd_prev_clicked (GtkWidget *widget, gpointer data);
void bmd_next_clicked (GtkWidget *widget, gpointer data);

#endif
