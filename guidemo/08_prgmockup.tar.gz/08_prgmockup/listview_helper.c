/**
 * Listview helper functions
 *
 *  M. Horauer
 */

#include "listview_helper.h"

/****************************************************************** getNextId */
gint
get_next_id(void)
{
  return 12;
}

/*************************************************************** getDateStamp */
void
get_datestamp(gchar *ds)
{
  GTimeVal  time;
  GDate     date;

  g_get_current_time(&time);
  g_date_clear(&date, 1);
  g_date_set_time_val(&date, &time);
  g_date_strftime(ds, 256, "%F", &date);
}
/** EOF */