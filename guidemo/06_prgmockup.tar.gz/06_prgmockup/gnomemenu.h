/**
 * GNOME/GTK+ Menu Demo Application using a GtkApplication class
 *
 * M. Horauer
 */
#ifndef _gnomemenu_
#define _gnomemenu_


#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>

/******************************************************************** GLOBALS */
extern GtkWidget *window;

#endif