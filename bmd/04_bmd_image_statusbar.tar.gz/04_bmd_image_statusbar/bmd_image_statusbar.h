#ifndef _bmd_image_statusbar_
#define _bmd_image_statusbar_

void prev_clicked (GtkWidget *widget, gpointer data);
void next_clicked (GtkWidget *widget, gpointer data);


#endif
