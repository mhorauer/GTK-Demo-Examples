/**
 * Very basic linked list demo using the GLib library.
 *
 * M. Horauer
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <glib.h>

/**************************************************************** DEFINITIONS */
typedef struct {
  char* inDate;
  char* idNr;
  char* email;
  char* givenName;
  char* familyName;
  char* street;
  char* city;
  char* zipCode;
  char* phone;
  int* bYear;
  int* bMonth;
  int* bDay;
} student;

/***************************************************************** PROTOTYPES */
static int readFile2List (GList** l, char *filename);
static gint sort_familyName(gconstpointer a, gconstpointer b, gpointer data);
static gint sort_idNr(gconstpointer a, gconstpointer b, gpointer data);
static void prt(gpointer stud);
static void wrt(gpointer stud, gpointer fp);

/****************************************************************** FUNCTIONS */
static gint
sort_familyName(gconstpointer a, gconstpointer b, gpointer data)
{
  return strcmp( ((student*)a)->familyName, ((student*)b)->familyName );
}

static gint
sort_idNr(gconstpointer a, gconstpointer b, gpointer data)
{
  return strcmp( ((student*)a)->idNr, ((student*)b)->idNr );
}

static void
prt(gpointer stud)
{
  printf("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%d\t%d\t%d\n",
                           ((student*)stud)->inDate,
                           ((student*)stud)->idNr,
                           ((student*)stud)->email,
                           ((student*)stud)->familyName,
                           ((student*)stud)->givenName,
                           ((student*)stud)->street,
                           ((student*)stud)->city,
                           ((student*)stud)->zipCode,
                           ((student*)stud)->phone,
                           *((student*)stud)->bYear,
                           *((student*)stud)->bMonth,
                           *((student*)stud)->bDay);
}

static void
wrt(gpointer stud, gpointer fp)
{
  fprintf((FILE*)fp, "%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d\n",
                           ((student*)stud)->inDate,
                           ((student*)stud)->idNr,
                           ((student*)stud)->email,
                           ((student*)stud)->familyName,
                           ((student*)stud)->givenName,
                           ((student*)stud)->street,
                           ((student*)stud)->city,
                           ((student*)stud)->zipCode,
                           ((student*)stud)->phone,
                           *((student*)stud)->bYear,
                           *((student*)stud)->bMonth,
                           *((student*)stud)->bDay);
}

static int
readFile2List (GList** l, char *filename)
{
  char buffer[256];
  char * token;
  FILE *fp;
  student *ptr;

  fp=fopen(filename, "r");
  if(fp == NULL)
  {
    puts("Failed to open file");
    return 0;
  }
  while(fgets(buffer, sizeof(buffer), fp) != NULL)
  {
    if (buffer[0]=='\n')
      break;
    /* allocate memory for the pointers */
    ptr = (student *) malloc (sizeof(student));
    /* get inscription date */
    token = strtok(buffer,",");
    ptr->inDate=(char *)malloc(sizeof(char)*sizeof(token));
    strcpy(ptr->inDate,token);
    /* get idNr */
    token = strtok(NULL,",");
    ptr->idNr=(char *)malloc(sizeof(char)*sizeof(token));
    strcpy(ptr->idNr,token);
    /* get email */
    token = strtok(NULL,",");
    ptr->email=(char *)malloc(sizeof(char)*sizeof(token));
    strcpy(ptr->email,token);
    /* get given name */
    token = strtok(NULL,",");
    ptr->givenName=(char *)malloc(sizeof(char)*sizeof(token));
    strcpy(ptr->givenName,token);
    /* get family name */
    token = strtok(NULL,",");
    ptr->familyName=(char *)malloc(sizeof(char)*sizeof(token));
    strcpy(ptr->familyName,token);
    /* get street */
    token = strtok(NULL,",");
    ptr->street=(char *)malloc(sizeof(char)*sizeof(token));
    strcpy(ptr->street,token);
    /* get city */
    token = strtok(NULL,",");
    ptr->city=(char *)malloc(sizeof(char)*sizeof(token));
    strcpy(ptr->city,token);
    /* get ZIP */
    token = strtok(NULL,",");
    ptr->zipCode=(char *)malloc(sizeof(char)*sizeof(token));
    strcpy(ptr->zipCode,token);
    /* get phone */
    token = strtok(NULL,",");
    ptr->phone=(char *)malloc(sizeof(char)*sizeof(token));
    strcpy(ptr->phone,token);
    /* get year */
    token = strtok(NULL, ",");
    ptr->bYear=(int *)malloc(sizeof(int));
    sscanf (token, "%d", ptr->bYear);
    /* get month */
    token = strtok(NULL, ",");
    ptr->bMonth=(int *)malloc(sizeof(int));
    sscanf (token, "%d", ptr->bMonth);
    /* get day */
    token = strtok(NULL, ",");
    ptr->bDay=(int *)malloc(sizeof(int));
    sscanf (token, "%d", ptr->bDay);

    *l = g_list_append(*l, ptr);
  }
  if( fclose(fp) != 0 )
  {
    puts("Failed to close file.");
    return 0;
  }
  return 1;
}

static int
writeList2File (GList** l, char *filename)
{
  FILE *fp;

  fp=fopen(filename, "w+");
  if(fp == NULL)
  {
    puts("Failed to open file");
    return 0;
  }
  g_list_foreach(*l, (GFunc)wrt, fp);
  if( fclose(fp) != 0 )
  {
    puts("Failed to close file.");
    return 0;
  }
  return 1;
}

static void
freeList (student *p, gpointer unused)
{
    g_free(p->inDate);
    g_free(p->idNr);
    g_free(p->email);
    g_free(p->givenName);
    g_free(p->familyName);
    g_free(p->street);
    g_free(p->city);
    g_free(p->zipCode);
    g_free(p->phone);
    g_free(p->bYear);
    g_free(p->bMonth);
    g_free(p->bDay);
    g_free(p);
}

/*********************************************************************** MAIN */
int
main( int argc, char** argv )
{
  GList* l = NULL;
  int ret = 0;
  student *p = NULL;

  if (argc != 3)
  {
    printf("Usage: dlistdemo in.csv out.csv\n");
    printf("                 in.csv .... CSV file containing data\n");
    printf("                 out.csv ... new CSV file\n\n");
    exit(EXIT_FAILURE);
  }
  ret = readFile2List(&l, argv[1]);
  if (ret != 0)
  {
    printf("-------- SORT by Family Name -------\n");
    /* sort list by family name */
    l = g_list_sort(l, (GCompareFunc)sort_familyName);
    /* print the list */
    g_list_foreach(l, (GFunc)prt, NULL);
    printf("\n-------- SORT by idNr ------------\n");
    /* sort list by idNr */
    l = g_list_sort(l, (GCompareFunc)sort_idNr);
    /* print the list */
    g_list_foreach(l, (GFunc)prt, NULL);

    /* add an entry to the list - here hardcoded */
    p = (student *) malloc (sizeof(student));
    p->inDate=(char *)malloc(sizeof(char)*30);
    strcpy(p->inDate,"2014-05-19");
    p->idNr=(char *)malloc(sizeof(char)*30);
    strcpy(p->idNr,"201400003");
    p->email=(char *)malloc(sizeof(char)*30);
    strcpy(p->email,"uschi.squaw@fh.at");
    p->givenName=(char *)malloc(sizeof(char)*30);
    strcpy(p->givenName,"Uschi");
    p->familyName=(char *)malloc(sizeof(char)*30);
    strcpy(p->familyName,"Squaw");
    p->street=(char *)malloc(sizeof(char)*30);
    strcpy(p->street,"Wigwam 3");
    p->city=(char *)malloc(sizeof(char)*30);
    strcpy(p->city,"Apache");
    p->zipCode=(char *)malloc(sizeof(char)*30);
    strcpy(p->zipCode,"U-7070");
    p->phone=(char *)malloc(sizeof(char)*30);
    strcpy(p->phone,"0520363637");
    p->bYear=(int *)malloc(sizeof(int));
    sscanf ("1985", "%d", p->bYear);
    p->bMonth=(int *)malloc(sizeof(int));
    sscanf ("6", "%d", p->bMonth);
    p->bDay=(int *)malloc(sizeof(int));
    sscanf ("6", "%d", p->bDay);
    l = g_list_append(l, p);

    /* write the entire list to a new file */
    writeList2File(&l,argv[2]);

    /* free the list */
    g_list_foreach(l, (GFunc) freeList, NULL);
    g_list_free(l);
  }
  return 0;
}

/** EOF */