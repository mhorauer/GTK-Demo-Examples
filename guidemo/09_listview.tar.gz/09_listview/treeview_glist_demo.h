#ifndef _treeview_glist_demo_
#define _treeview_glist_demo_

extern GtkWidget *treeview;

#endif