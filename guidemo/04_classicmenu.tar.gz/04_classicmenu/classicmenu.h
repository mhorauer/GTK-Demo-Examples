/**
 * Classic GTK+ Menu Demo using a GtkApplication class
 *
 * M. Horauer
 */
#ifndef _classicmenu_
#define _classicmenu_

#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>

/******************************************************************** GLOBALS */
extern GtkWidget *window;


#endif