/**
 *  @brief LIST VIEW & GLIST Demo
 *  based on gtk3-demo code "Tree View > Editable Cells"
 *  removed some functionality (editable cells, g_array) and
 *  added other functionality (g_list, print to STDOUT)
 *
 *  M. Horauer
 */
#ifndef _listview_
#define _listview_

#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>


/* data structure used to store the data - we use a double-linked list here */
typedef struct {
  gint   age;
  gchar* name;
  gint   result;
} item;

/* enums required for the treeview */
enum {
  COLUMN_ITEM_AGE,
  COLUMN_ITEM_NAME,
  COLUMN_ITEM_RESULT,
  NUM_ITEM_COLUMNS
};


/* ADD Button Callback */
void add_item (GSimpleAction *action, GVariant *parameter, gpointer data);
/* REMOVE Button Callback */
void remove_item (GSimpleAction *action, GVariant *parameter, gpointer data);
/* PRINT Button Callback */
void print_list (GSimpleAction *action, GVariant *parameter, gpointer data);
void prtList(gpointer p);
void terminate (void);

/* Functions */
void add_initial_values(void);
GtkTreeModel *create_items_model(void);
void add_columns (GtkTreeView  *treeview, GtkTreeModel *items_model,
                         GtkTreeModel *numbers_model);

#endif