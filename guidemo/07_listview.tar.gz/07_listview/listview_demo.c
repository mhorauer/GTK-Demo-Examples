/**
 *  @brief LIST VIEW Demo
 *
 *  based on gtk3-demo code "Tree View > Editable Cells"
 *  removed some functionality (editable cells, g_array) and
 *  added other functionality (print to STDOUT)
 *
 *  M. Horauer
 */
#include "listview_callbacks.h"

/**************************************************************** MAIN WINDOW */
static void
activate(GtkApplication *app, gpointer data)
{
  GtkWidget *window;
  GtkWidget *vbox;
  GtkWidget *hbox;
  GtkWidget *sw;
  GtkWidget *abutton, *rbutton, *pbutton;
  GtkWidget *treeview;
  GtkTreeModel *items_model;

  // map menu actions to callbacks
  const GActionEntry app_actions[] = {
    { "additem", add_item, NULL, NULL, NULL },
    { "removeitem", remove_item, NULL, NULL, NULL },
    { "printitem", dump_store, NULL, NULL, NULL }
  };

  // create window, etc
  window = gtk_application_window_new(app);
  gtk_window_set_application(GTK_WINDOW (window), GTK_APPLICATION(app));
  gtk_window_set_title(GTK_WINDOW(window),"GNOME List Demo");
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
  gtk_window_set_default_size(GTK_WINDOW(window), 500, 300);
  gtk_container_set_border_width(GTK_CONTAINER (window), 5);
  gtk_widget_show(window);

  // add a box with a scorlled window
  vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
  gtk_container_add(GTK_CONTAINER (window), vbox);
  gtk_box_pack_start(GTK_BOX (vbox), gtk_label_new ("Add/remove List entries"),
                     FALSE, FALSE, 0);
  sw = gtk_scrolled_window_new(NULL, NULL);
  gtk_scrolled_window_set_shadow_type(GTK_SCROLLED_WINDOW (sw),
                                      GTK_SHADOW_ETCHED_IN);
  gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW (sw),
                                 GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
  gtk_box_pack_start(GTK_BOX (vbox), sw, TRUE, TRUE, 0);

  // create model
  items_model = create_items_model();
  // create tree view
  treeview = gtk_tree_view_new_with_model(items_model);
  gtk_tree_selection_set_mode(gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview)),
                              GTK_SELECTION_SINGLE);
  add_columns(GTK_TREE_VIEW(treeview), items_model, NULL);
  g_object_unref(items_model);
  gtk_container_add(GTK_CONTAINER(sw), treeview);

  // some buttons
  hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 4);
  gtk_box_set_homogeneous(GTK_BOX(hbox), TRUE);
  gtk_box_pack_start(GTK_BOX (vbox), hbox, FALSE, FALSE, 0);
  abutton = gtk_button_new_with_label("Add item");
  gtk_box_pack_start(GTK_BOX(hbox), abutton, TRUE, TRUE, 0);
  gtk_actionable_set_action_name(GTK_ACTIONABLE(abutton),"app.additem");

  rbutton = gtk_button_new_with_label("Remove item");
  gtk_box_pack_start(GTK_BOX(hbox), rbutton, TRUE, TRUE, 0);
  gtk_widget_set_tooltip_text(rbutton,"You need to select an item");
  gtk_actionable_set_action_name(GTK_ACTIONABLE(rbutton),"app.removeitem");

  pbutton = gtk_button_new_with_label("Print List");
  gtk_box_pack_start(GTK_BOX(hbox), pbutton, TRUE, TRUE, 0);
  gtk_widget_set_tooltip_text(pbutton,"Prints to STDOUT");
  gtk_actionable_set_action_name(GTK_ACTIONABLE(pbutton),"app.printitem");

  g_action_map_add_action_entries(G_ACTION_MAP (app), app_actions,
                                  G_N_ELEMENTS (app_actions),
                                  (gpointer)treeview);

  gtk_widget_show_all(GTK_WIDGET(window));
}

/*********************************************************************** main */
int
main (int argc, char **argv)
{
  GtkApplication *app;
  int status;

  app = gtk_application_new("org.gtk.example",G_APPLICATION_FLAGS_NONE);
  g_signal_connect(app, "activate", G_CALLBACK(activate), NULL);
  status = g_application_run(G_APPLICATION(app), argc, argv);
  g_object_unref(app);
  return status;
}
/*! EOF */