/**
 * Listview GNOME/GTK+ Application
 *
 * M. Horauer
 */
#ifndef _listview_
#define _listview_

#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>

/***************************************************************** PROTOTYPES */
void
select_callback (GtkCellRendererToggle *cell, gchar *path_str, gpointer data);
void
add_columns (GtkTreeView *treeview);
GtkTreeModel *
create_model (void);

/******************************************************************** GLOBALS */
extern GtkTreeModel *model;

/**************************************************************** DEFINITIONS */
typedef struct {
  gboolean fixed;
  gchar* inDate;
  gchar* iD;
  gchar* email;
  gchar* givenName;
  gchar* familyName;
  gchar* street;
  gchar* city;
  gchar* zipCode;
  gchar* phone;
  guint  bYear;
  guint  bMonth;
  guint  bDay;
} student;

enum {
  COLUMN_FIXED,
  COLUMN_DATE,
  COLUMN_ID,
  COLUMN_EMAIL,
  COLUMN_GNAME,
  COLUMN_FNAME,
  COLUMN_STREET,
  COLUMN_CITY,
  COLUMN_ZIP,
  COLUMN_PHONE,
  COLUMN_YEAR,
  COLUMN_MONTH,
  COLUMN_DAY,
  NUM_COLUMNS
};

#endif
/** EOF */