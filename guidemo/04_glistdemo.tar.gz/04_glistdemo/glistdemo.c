/*! Very basic linked list demo using the GLib library.
 * M. Horauer
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <glib.h>
#include <glib/gprintf.h>

/***************************************************************** PROTOTYPES */
void printout(gpointer item);

/******************************************************************** GLOBALS */
struct student {
  gchar name[20];
  gint age;
};

/****************************************************************** FUNCTIONS */
void printout(gpointer item)
{
  printf("%s %d\n", ((struct student *)item)->name, 
                    ((struct student *)item)->age);
}

int main(void)
{
  char str[20];
  struct student *myStudent = NULL;
  GList *list = NULL;
  
  while(1)
  { 
    myStudent = g_new(struct student, 1);
    g_print("Name > "); 
    fgets(str,20,stdin); 
    str[strlen(str)-1]='\0';
    strcpy(myStudent->name,str);
    g_print(" Age > "); 
    fgets(str,20,stdin);
    myStudent->age = atoi(str);
    g_print("One more? (Y/N) > ");
    fgets(str,20,stdin);
    list = g_list_prepend(list, (gpointer)myStudent);    
    if (str[0] == 'n' || str[0] == 'N')
      break;
  }
  g_printf("Length of the list %d\n", g_list_length(list));
  list = g_list_sort(list, (GCompareFunc)strcmp);
  g_list_foreach(list, (GFunc)printout, NULL);
  
  g_list_free(list);
  return 0;
}
/*! EOF */
