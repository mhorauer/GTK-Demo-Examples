/**
 * Listview helper functions
 *
 *  M. Horauer
 */
#ifndef _listview_helper_
#define _listview_helper_

#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include <glib.h>
#include <glib/gprintf.h>

gint get_next_id(void);
void get_datestamp(gchar *ds);

#endif