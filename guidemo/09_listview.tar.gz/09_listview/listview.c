/**
 *  @brief LIST VIEW & GLIST Demo
 *  based on gtk3-demo code "Tree View > Editable Cells"
 *  removed some functionality (editable cells, g_array) and
 *  added other functionality (g_list, print to STDOUT)
 *
 *  M. Horauer
 */
#include "listview.h"
#include "treeview_glist_demo.h"

#define INITIAL 1

GList *l = NULL;
/* create some data to work on */
static gint j = 0;

item somedata[] = {
  {22, "Marry", 60},
  {23, "Thomas", 63},
  {26, "Martin", 66},
  {25, "Eva", 83},
  {22, "Chris", 70},
  {24, "Adam", 76},
  {21, "Steve", 72},
  {28, "Paul", 76}
};


/************************************************************ PRINT CALLBACKS */
void prtList(gpointer p)
{
  printf("%d\t%s\t%d\n", ((item*)p)->age, ((item*)p)->name,
         ((item*)p)->result);
}

/********************************************************* PRINTLIST Callback */
void print_list (GSimpleAction *action, GVariant *parameter, gpointer data)
{
    g_list_foreach(l, (GFunc)prtList, NULL);
    printf("------------------\n\n");
}
/********************************************************* TERMINATE CALLBACK */
void terminate (void)
{
  if (l != NULL)
  {
    /* free the list */
    g_list_foreach(l, (GFunc) g_free, NULL);
    g_list_free(l);
  }
  gtk_main_quit();
}

/************************************************************* Initialization */
void add_initial_values(void)
{
  item* foo = NULL;

  foo = (item*)g_malloc(2*sizeof(gint)+strlen(somedata[0].name)*sizeof(gchar));
  foo->age = somedata[0].age;
  foo->name = g_strdup (somedata[0].name);
  foo->result = somedata[0].result;
  l = g_list_append(l, foo);
}

/*************************************************************** ADD CALLBACK */
void add_item (GSimpleAction *action, GVariant *parameter, gpointer data)
{
  item* foo = NULL;
  GtkTreeIter iter;
  GList* k;

  if (j == 7)
    j = 0;
  else
    j++;
  GtkTreeModel *model = gtk_tree_view_get_model (GTK_TREE_VIEW(treeview));
  foo = (item*)g_malloc(2*sizeof(gint)+strlen(somedata[j].name)*sizeof(gchar));
  foo->age = somedata[j].age;
  foo->name = g_strdup (somedata[j].name);
  foo->result = somedata[j].result;
  l = g_list_append (l, foo);

  k = g_list_last(l);
  gtk_list_store_append (GTK_LIST_STORE (model), &iter);
  gtk_list_store_set (GTK_LIST_STORE (model), &iter,
                      COLUMN_ITEM_AGE, ((item*)(k)->data)->age,
                      COLUMN_ITEM_NAME, ((item*)(k)->data)->name,
                      COLUMN_ITEM_RESULT, ((item*)(k)->data)->result,
                      -1);
}
/************************************************************ REMOVE CALLBACK */
void remove_item (GSimpleAction *action, GVariant *parameter, gpointer data)
{
  GtkTreeIter iter;
  gint m = 0;
  GtkTreePath* path;

  GtkTreeModel *model = gtk_tree_view_get_model (GTK_TREE_VIEW(treeview));
  GtkTreeSelection *selection = gtk_tree_view_get_selection (GTK_TREE_VIEW(treeview));

  if (gtk_tree_selection_get_selected (selection, NULL, &iter))
  {
    path = gtk_tree_model_get_path (model, &iter);
    // m is the selected line
    m = gtk_tree_path_get_indices (path)[0];
    gtk_list_store_remove (GTK_LIST_STORE (model), &iter);

    // delete the element (line m) from the list
    l = g_list_delete_link(l,  g_list_nth (l,m));
    gtk_tree_path_free (path);
  }
}

/******************************************************** Create a List Store */
GtkTreeModel *create_items_model (void)
{
  GtkListStore *model;
#if INITIAL
  GtkTreeIter iter;
  GList* k;

  add_initial_values();
#endif
  /* create list store */
  model = gtk_list_store_new (NUM_ITEM_COLUMNS, G_TYPE_INT, G_TYPE_STRING,
                              G_TYPE_INT, G_TYPE_BOOLEAN);
#if INITIAL
  /* add items */
  for (k = l; k; k = k->next) {
    gtk_list_store_append (model, &iter);
    gtk_list_store_set (model, &iter,
                        COLUMN_ITEM_AGE, ((item*)(k)->data)->age,
                        COLUMN_ITEM_NAME, ((item*)(k)->data)->name,
                        COLUMN_ITEM_RESULT, ((item*)(k)->data)->result,
                        -1);
  }
#endif
  return GTK_TREE_MODEL (model);
}

/***************************************** FUNCTION to construct the TREEVIEW */
void add_columns (GtkTreeView  *treeview, GtkTreeModel *items_model,
                         GtkTreeModel *numbers_model)
{
  GtkCellRenderer *renderer;

  /* age column */
  renderer = gtk_cell_renderer_text_new ();
  g_object_set_data (G_OBJECT (renderer), "column",
                     GINT_TO_POINTER (COLUMN_ITEM_AGE));
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (treeview),
      -1, "Number", renderer, "text", COLUMN_ITEM_AGE, NULL);

  /* name column */
  renderer = gtk_cell_renderer_text_new ();
  g_object_set_data (G_OBJECT (renderer), "column",
                     GINT_TO_POINTER (COLUMN_ITEM_NAME));
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (treeview),
      -1, "Product", renderer, "text", COLUMN_ITEM_NAME, NULL);

  /* result column */
  renderer = gtk_cell_renderer_progress_new ();
  g_object_set_data (G_OBJECT (renderer), "column",
                     GINT_TO_POINTER (COLUMN_ITEM_RESULT));
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (treeview),
      -1, "Result", renderer, "value", COLUMN_ITEM_RESULT, NULL);
}
/** EOF */