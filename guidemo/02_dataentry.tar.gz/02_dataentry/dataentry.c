/**
 * Demo GTK+ Application that illustrates data entry.
 *
 * M. Horauer
 */
#include <gtk/gtk.h>

typedef struct {
  GtkWidget *dateDate;
  GtkWidget *idNbr;
  GtkWidget *emailAddr;
  GtkWidget *gnameEntry;
  GtkWidget *fnameEntry;
  GtkWidget *streetEntry;
  GtkWidget *cityEntry;
  GtkWidget *zipEntry;
  GtkWidget *phoneEntry;
  GtkWidget *byearSpin;
  GtkWidget *bmonthSpin;
  GtkWidget *bdaySpin;
} diaWidgets;

typedef struct {
  GtkApplication *app;
  GtkWidget *window;
  GtkWidget *img;
  diaWidgets *d;
} appWidgets;

/***************************************************************** PROTOTYPES */
static void activate(GtkApplication *app, gpointer user_data);
static void img_callback(GtkWidget *widget, GdkEvent *event, gpointer user_data);
static void cancel_callback(GtkWidget *widget, gpointer user_data);
static void clear_callback(GtkWidget *widget, gpointer user_data);
static void add_callback(GtkWidget *widget, gpointer user_data);

/**************************************************************** imgCallback */
static void
img_callback(GtkWidget *widget, GdkEvent *event, gpointer user_data)
{
  GtkWidget *imgDialog;
  GtkFileFilter *filter;
  gint res;
  appWidgets *a = (appWidgets *)user_data;

  filter = gtk_file_filter_new();
  imgDialog = gtk_file_chooser_dialog_new("Open File", GTK_WINDOW(a->window),
                                          GTK_FILE_CHOOSER_ACTION_OPEN,
                                          "_Cancel", GTK_RESPONSE_CANCEL,
                                          "_Open", GTK_RESPONSE_ACCEPT, NULL);
  gtk_file_filter_add_mime_type(GTK_FILE_FILTER(filter), "image/png");
  gtk_file_filter_add_mime_type(GTK_FILE_FILTER(filter), "image/jpg");
  gtk_file_chooser_set_filter(GTK_FILE_CHOOSER(imgDialog),filter);

  res = gtk_dialog_run (GTK_DIALOG (imgDialog));
  if (res == GTK_RESPONSE_ACCEPT)
    {
      char *filename;
      GtkFileChooser *chooser = GTK_FILE_CHOOSER(imgDialog);
      filename = gtk_file_chooser_get_filename(chooser);
      gtk_image_set_from_file(GTK_IMAGE(a->img), filename);
      g_free (filename);
    }
  gtk_widget_destroy(imgDialog);
}

/************************************************************ Cancel Callback */
static void
cancel_callback(GtkWidget *widget, gpointer user_data)
{
  appWidgets *a = (appWidgets *)user_data;

  g_print("Cancel pressed!\n");
  g_application_quit(G_APPLICATION(a->app));
}

/************************************************************* Clear Callback */
static void
clear_callback(GtkWidget *widget, gpointer user_data)
{
  appWidgets *a = (appWidgets *)user_data;

  g_print("Clear pressed!\n");
  gtk_label_set_label(GTK_LABEL(a->d->dateDate),"XXXX-XX-XX");
  gtk_label_set_label(GTK_LABEL(a->d->idNbr),"14012345");
  gtk_label_set_label(GTK_LABEL(a->d->emailAddr),"muster@example.domain");
  gtk_entry_set_text(GTK_ENTRY(a->d->gnameEntry),"");
  gtk_entry_set_text(GTK_ENTRY(a->d->fnameEntry),"");
  gtk_entry_set_text(GTK_ENTRY(a->d->streetEntry),"");
  gtk_entry_set_text(GTK_ENTRY(a->d->cityEntry),"");
  gtk_entry_set_text(GTK_ENTRY(a->d->zipEntry),"");
  gtk_entry_set_text(GTK_ENTRY(a->d->phoneEntry),"");
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(a->d->byearSpin), 1990);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(a->d->bmonthSpin), 1);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(a->d->bdaySpin), 1);
  gtk_image_set_from_file(GTK_IMAGE(a->img), "src/avatar.png");
}

/*************************************************************** Add Callback */
static void
add_callback(GtkWidget *widget, gpointer user_data)
{
  appWidgets *a = (appWidgets *)user_data;

  g_print("Add pressed!\n");
  g_print("-------------------------------\n");
  g_print("Date: %s\n",gtk_label_get_text(GTK_LABEL(a->d->dateDate)));
  g_print("ID: %s\n",gtk_label_get_text(GTK_LABEL(a->d->idNbr)));
  g_print("eMail: %s\n",gtk_label_get_text(GTK_LABEL(a->d->emailAddr)));
  g_print("Given Name: %s\n",gtk_entry_get_text(GTK_ENTRY(a->d->gnameEntry)));
  g_print("Family Name: %s\n",gtk_entry_get_text(GTK_ENTRY(a->d->fnameEntry)));
  g_print("Street: %s\n",gtk_entry_get_text(GTK_ENTRY(a->d->streetEntry)));
  g_print("City: %s\n",gtk_entry_get_text(GTK_ENTRY(a->d->cityEntry)));
  g_print("ZIP: %s\n",gtk_entry_get_text(GTK_ENTRY(a->d->zipEntry)));
  g_print("Phone: %s\n",gtk_entry_get_text(GTK_ENTRY(a->d->phoneEntry)));
  g_print("Birth: %.0lf-%.0lf-%.0lf\n",
          gtk_spin_button_get_value(GTK_SPIN_BUTTON(a->d->byearSpin)),
          gtk_spin_button_get_value(GTK_SPIN_BUTTON(a->d->bmonthSpin)),
          gtk_spin_button_get_value(GTK_SPIN_BUTTON(a->d->bdaySpin)));
  g_print("-------------------------------\n");
}

/***************************************************************** ADD WINDOW */
static void
activate(GtkApplication *app, gpointer user_data)
{
  GtkWidget *box;
  GtkWidget *ebox;
  GtkWidget *grid;
  GtkWidget *photoLabel;
  GtkWidget *dateLabel;
  GtkWidget *idLabel;
  GtkWidget *emailLabel;
  GtkWidget *gnameLabel;
  GtkWidget *fnameLabel;
  GtkWidget *streetLabel;
  GtkWidget *cityLabel;
  GtkWidget *zipLabel;
  GtkWidget *phoneLabel;
  GtkWidget *birthLabel;
  GtkWidget *cButton;
  GtkWidget *lButton;
  GtkWidget *aButton;
  appWidgets *a = (appWidgets *)user_data;


  /* create a window with title, default size,and icons */
  a->window = gtk_application_window_new(a->app);
  gtk_window_set_application(GTK_WINDOW(a->window), GTK_APPLICATION(a->app));
  gtk_window_set_title(GTK_WINDOW(a->window), "Student Management Toolbox");
  gtk_window_set_default_size(GTK_WINDOW(a->window), 400,300);
  gtk_window_set_default_icon_from_file("icon.png", NULL);
  gtk_window_set_resizable(GTK_WINDOW(a->window), FALSE);

  box = gtk_box_new(GTK_ORIENTATION_VERTICAL,4);
  gtk_container_add(GTK_CONTAINER(a->window), GTK_WIDGET(box));
  gtk_container_set_border_width(GTK_CONTAINER(a->window), 10);

  /* grid: image and labels */
  grid = gtk_grid_new();
  gtk_grid_set_column_spacing(GTK_GRID(grid),5);
  gtk_grid_set_row_spacing(GTK_GRID(grid),5);
  gtk_widget_set_size_request(GTK_WIDGET(grid),400,90);
  gtk_widget_set_valign(GTK_WIDGET(grid),GTK_ALIGN_CENTER);
  gtk_widget_set_halign(GTK_WIDGET(grid),GTK_ALIGN_CENTER);
  gtk_box_pack_start(GTK_BOX(box), GTK_WIDGET(grid), TRUE, TRUE, 0);

  /* clickable image top left */
  photoLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "Photo:", "xalign", 1.0,
                             "yalign", 0.5, NULL);
  gtk_widget_set_size_request(GTK_WIDGET(photoLabel),80,30);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(photoLabel),0,0,1,1);
  ebox = gtk_event_box_new();
  gtk_widget_set_size_request(GTK_WIDGET(ebox),150,90);
  gtk_widget_set_valign(GTK_WIDGET(ebox),GTK_ALIGN_CENTER);
  gtk_widget_set_halign(GTK_WIDGET(ebox),GTK_ALIGN_CENTER);
  a->img = gtk_image_new_from_file("src/avatar.png");
  gtk_container_add (GTK_CONTAINER(ebox), a->img);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(ebox),1,0,1,3);
  g_signal_connect (G_OBJECT(ebox),"button_press_event",
                    G_CALLBACK(img_callback),(gpointer)a);

  dateLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "Date:",
                             "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_widget_set_size_request(GTK_WIDGET(dateLabel),150,30);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(dateLabel),2,0,1,1);
  a->d->dateDate = gtk_widget_new(GTK_TYPE_LABEL, "label", "XXXX-XX-XX",
                                  "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_widget_set_size_request(GTK_WIDGET(a->d->dateDate),150,30);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(a->d->dateDate),3,0,1,1);

  idLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "Student ID:",
                           "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(idLabel),2,1,1,1);
  a->d->idNbr = gtk_widget_new(GTK_TYPE_LABEL, "label", "201412345",
                               "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(a->d->idNbr),3,1,1,1);

  emailLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "eMail:",
                              "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(emailLabel),2,2,1,1);
  a->d->emailAddr = gtk_widget_new(GTK_TYPE_LABEL, "label", "tom.bone@uni.edu",
                                   "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(a->d->emailAddr),3,2,1,1);

  gnameLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "Given Name:",
                              "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(gnameLabel),0,3,1,1);
  a->d->gnameEntry = gtk_entry_new();
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(a->d->gnameEntry),1,3,1,1);

  fnameLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "Family Name:",
                              "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(fnameLabel),2,3,1,1);
  a->d->fnameEntry = gtk_entry_new();
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(a->d->fnameEntry),3,3,1,1);

  streetLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "Street:",
                               "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(streetLabel),0,4,1,1);
  a->d->streetEntry = gtk_entry_new();
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(a->d->streetEntry),1,4,1,1);

  cityLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "City:",
                             "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(cityLabel),2,4,1,1);
  a->d->cityEntry = gtk_entry_new();
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(a->d->cityEntry),3,4,1,1);

  zipLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "ZIP Code:",
                            "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(zipLabel),0,5,1,1);
  a->d->zipEntry = gtk_entry_new();
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(a->d->zipEntry),1,5,1,1);

  phoneLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "Phone:",
                              "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(phoneLabel),2,5,1,1);
  a->d->phoneEntry = gtk_entry_new();
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(a->d->phoneEntry),3,5,1,1);

  birthLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "Date of Birth:",
                              "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(birthLabel),0,6,1,1);
  a->d->byearSpin = gtk_spin_button_new_with_range(1900,2000,1);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(a->d->byearSpin), 1990);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(a->d->byearSpin),1,6,1,1);
  a->d->bmonthSpin = gtk_spin_button_new_with_range(1,12,1);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(a->d->bmonthSpin),2,6,1,1);
  a->d->bdaySpin = gtk_spin_button_new_with_range(1,31,1);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(a->d->bdaySpin),3,6,1,1);


  /* lowerbox: buttons */
  cButton = gtk_button_new_with_mnemonic ("_Cancel");
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(cButton),1,7,1,1);
  g_signal_connect(G_OBJECT(cButton), "clicked", G_CALLBACK(cancel_callback),
                   (gpointer)a);
  lButton = gtk_button_new_with_mnemonic ("C_lear");
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(lButton),2,7,1,1);
  g_signal_connect(G_OBJECT(lButton), "clicked", G_CALLBACK(clear_callback),
                   (gpointer)a);
  aButton = gtk_button_new_with_mnemonic ("_Add");
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(aButton),3,7,1,1);
  g_signal_connect(G_OBJECT(aButton), "clicked", G_CALLBACK(add_callback),
                   (gpointer)a);

  /* display all widgets */
  gtk_widget_show_all (GTK_WIDGET(a->window));
}

/*********************************************************************** main */
int
main (int argc, char **argv)
{
  int status;
  appWidgets *a = g_malloc(sizeof(appWidgets));
  a->d = g_malloc(sizeof(diaWidgets));

  a->app = gtk_application_new ("org.gtk.example",G_APPLICATION_FLAGS_NONE);
  g_signal_connect(G_OBJECT(a->app), "activate", G_CALLBACK (activate),
                   (gpointer)a);
  status = g_application_run (G_APPLICATION(a->app), argc, argv);
  g_object_unref(a->app);

  g_free(a->d);
  g_free(a);
  return status;
}
/** EOF */