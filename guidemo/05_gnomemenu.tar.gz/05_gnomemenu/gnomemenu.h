/**
 * GNOME/GTK+ Menu Demo Application using a GtkApplication class
 *
 * M. Horauer
 */
#ifndef _gnomemenu_
#define _gnomemenu_


#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>

typedef struct {
  GtkApplication *app;
  GtkWidget *window;
} appWidgets;

#endif