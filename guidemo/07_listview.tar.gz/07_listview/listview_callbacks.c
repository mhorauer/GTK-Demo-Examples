/**
 *  @brief LIST VIEW Demo
 *
 *  based on gtk3-demo code "Tree View > Editable Cells"
 *  removed some functionality (editable cells, g_array) and
 *  added other functionality (print to STDOUT)
 *
 *  M. Horauer
 */
#include "listview_callbacks.h"

/* create some data to work on */
static gint j = 0;

item somedata[] = {
  {22, "Marry", 60},
  {23, "Thomas", 63},
  {26, "Martin", 66},
  {25, "Eva", 83},
  {22, "Chris", 70},
  {24, "Adam", 76},
  {21, "Steve", 72},
  {28, "Paul", 76}
};

/********************************************************* DUMPSTORE Callback */
void
dump_store(GSimpleAction *action, GVariant *parameter, gpointer data)
{
  GtkTreeModel *model;
  GtkTreeView *treeview = GTK_TREE_VIEW(data);

  model = gtk_tree_view_get_model(treeview);
  g_print("----------------------------------------\n");
  gtk_tree_model_foreach(model, foreach_func, NULL);
  g_print("----------------------------------------\n");
}

/* Function to print one row of the Liststore */
gboolean
foreach_func(GtkTreeModel *model, GtkTreePath *path, GtkTreeIter *iter,
              gpointer user_data)
{
  gchar *name, *tree_path_str;
  guint age, result;

  gtk_tree_model_get(model, iter,
                     COLUMN_ITEM_AGE, &age,
                     COLUMN_ITEM_NAME, &name,
                     COLUMN_ITEM_RESULT, &result,
                     -1);
  tree_path_str = gtk_tree_path_to_string(path);
  g_print("Row %s: Age %u, Name %s, Result %u\n", tree_path_str,
           age, name, result);
  g_free(tree_path_str);
  g_free(name);
  return FALSE;
}

/*************************************************************** ADD CALLBACK */
void
add_item(GSimpleAction *action, GVariant *parameter, gpointer data)
{
  GtkTreeIter iter;
  GtkTreeModel *model;
  GtkTreeView *treeview = GTK_TREE_VIEW(data);

  if (j == 7)
    j = 0;
  else
    j++;
  model = gtk_tree_view_get_model(treeview);
  gtk_list_store_append (GTK_LIST_STORE (model), &iter);
  gtk_list_store_set (GTK_LIST_STORE (model), &iter,
                      COLUMN_ITEM_AGE, somedata[j].age,
                      COLUMN_ITEM_NAME, somedata[j].name,
                      COLUMN_ITEM_RESULT, somedata[j].result,
                      -1);
}

/************************************************************ REMOVE CALLBACK */
void
remove_item(GSimpleAction *action, GVariant *parameter, gpointer data)
{
  GtkTreeIter iter;
  GtkTreePath* path;
  GtkTreeModel *model;
  GtkTreeSelection *selection;
  GtkTreeView *treeview = GTK_TREE_VIEW(data);

  model = gtk_tree_view_get_model(treeview);
  selection = gtk_tree_view_get_selection (treeview);
  if (gtk_tree_selection_get_selected (selection, NULL, &iter))
  {
    path = gtk_tree_model_get_path (model, &iter);
    gtk_list_store_remove (GTK_LIST_STORE (model), &iter);
    gtk_tree_path_free (path);
  }
}

/******************************************************** Create a List Store */
GtkTreeModel *
create_items_model(void)
{
  GtkListStore *model;
  GtkTreeIter iter;

  /* create list store */
  model = gtk_list_store_new(NUM_ITEM_COLUMNS, G_TYPE_INT, G_TYPE_STRING,
                             G_TYPE_INT, G_TYPE_BOOLEAN);
  /* add items */
  gtk_list_store_append (model, &iter);
  gtk_list_store_set(model, &iter,
                     COLUMN_ITEM_AGE, somedata[0].age,
                     COLUMN_ITEM_NAME, somedata[0].name,
                     COLUMN_ITEM_RESULT, somedata[0].result,
                     -1);
  return GTK_TREE_MODEL (model);
}

/***************************************** FUNCTION to construct the TREEVIEW */
void
add_columns (GtkTreeView  *treeview, GtkTreeModel *items_model,
             GtkTreeModel *numbers_model)
{
  GtkCellRenderer *renderer;

  /* age column */
  renderer = gtk_cell_renderer_text_new ();
  g_object_set_data (G_OBJECT (renderer), "column",
                     GINT_TO_POINTER (COLUMN_ITEM_AGE));
  gtk_tree_view_insert_column_with_attributes(treeview, -1, "Number", renderer,
                                              "text", COLUMN_ITEM_AGE, NULL);

  /* name column */
  renderer = gtk_cell_renderer_text_new ();
  g_object_set_data (G_OBJECT (renderer), "column",
                     GINT_TO_POINTER (COLUMN_ITEM_NAME));
  gtk_tree_view_insert_column_with_attributes(treeview,-1, "Product", renderer,
                                              "text", COLUMN_ITEM_NAME, NULL);

  /* result column */
  renderer = gtk_cell_renderer_progress_new ();
  g_object_set_data (G_OBJECT (renderer), "column",
                     GINT_TO_POINTER (COLUMN_ITEM_RESULT));
  gtk_tree_view_insert_column_with_attributes(treeview,-1, "Result", renderer,
                                              "value", COLUMN_ITEM_RESULT, NULL);
}
/** EOF */