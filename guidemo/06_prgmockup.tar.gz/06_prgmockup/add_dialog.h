/**
 * Add dialog for a GNOME/GTK+ Application
 *
 *  M. Horauer
 */
#ifndef _add_dialog_
#define _add_dialog_

#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include <glib.h>
#include <glib/gprintf.h>

/***************************************************************** PROTOTYPES */
void img_callback (GtkApplication *app, gpointer user_data);
void clear_entry_callback (void);
void name_entry_callback (GtkWidget *widget, gpointer user_data);
void add_dialog (gchar *message);

#endif
/** EOF */