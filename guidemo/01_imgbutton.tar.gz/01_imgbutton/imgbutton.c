/*! Demo GTK+ Application
 *  M. Horauer
 */
#include <gtk/gtk.h>
/******************************************************************** GLOBALS */
GtkWidget *window, *img;

/***************************************************************** PROTOTYPES */
static void activate (GtkApplication *app, gpointer user_data);
static void imgCallback (GtkApplication *app, gpointer user_data);


static void imgCallback (GtkApplication *app, gpointer user_data)
{
  GtkWidget *dialog;
  GtkFileChooserAction action = GTK_FILE_CHOOSER_ACTION_OPEN;
  gint res;

  dialog = gtk_file_chooser_dialog_new ("Open File",
                                        GTK_WINDOW(window),
                                        action,
                                        "_Cancel",
                                        GTK_RESPONSE_CANCEL,
                                        "_Open",
                                        GTK_RESPONSE_ACCEPT,
                                        NULL);

  res = gtk_dialog_run (GTK_DIALOG (dialog));
  if (res == GTK_RESPONSE_ACCEPT)
    {
      char *filename;
      GtkFileChooser *chooser = GTK_FILE_CHOOSER (dialog);
      filename = gtk_file_chooser_get_filename (chooser);
      //open_file (filename);
      gtk_image_set_from_file(GTK_IMAGE(img), filename);
      g_print("jipeee\n");
      g_free (filename);
    }

  gtk_widget_destroy (dialog);
}

/**************************************************************** MAIN WINDOW */
static void activate (GtkApplication *app, gpointer user_data)
{
  GtkWidget *box, *fbox, *ebox;

  /* create a window with title, default size,and icons */
  window = gtk_application_window_new (app);
  gtk_window_set_application (GTK_WINDOW (window), GTK_APPLICATION (app));
  gtk_window_set_title (GTK_WINDOW (window), "Student Management Toolbox");
  gtk_window_set_default_size (GTK_WINDOW (window), 500,300);
  gtk_window_set_default_icon_from_file("icon.png", NULL);

  box = gtk_box_new(GTK_ORIENTATION_VERTICAL,2);
  gtk_container_add(GTK_CONTAINER(window), GTK_WIDGET(box));

  fbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL,2);
  gtk_box_pack_start(GTK_BOX(box), GTK_WIDGET(fbox), FALSE, TRUE, 2);

  ebox = gtk_event_box_new();
  img = gtk_image_new_from_file("src/avatar.png");
  gtk_container_add (GTK_CONTAINER(ebox), img);
  gtk_box_pack_start(GTK_BOX(fbox), GTK_WIDGET(ebox), FALSE, TRUE, 2);
  g_signal_connect (G_OBJECT (ebox),"button_press_event",
                    G_CALLBACK (imgCallback),NULL);


  /* display all widgets */
  gtk_widget_show_all (GTK_WIDGET (window));
}

/*! \brief main */
int main (int argc, char **argv)
{
  GtkApplication *app;
  int status;

  app = gtk_application_new ("org.gtk.example",G_APPLICATION_FLAGS_NONE);
  g_signal_connect (app, "activate", G_CALLBACK (activate), NULL);
  status = g_application_run (G_APPLICATION (app), argc, argv);
  g_object_unref (app);
  return status;
}
/*! EOF */