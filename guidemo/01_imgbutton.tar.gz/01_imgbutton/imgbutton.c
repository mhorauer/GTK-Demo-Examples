/*! Demo GTK+ Application
 *  M. Horauer
 */
#include <gtk/gtk.h>

typedef struct {
  GtkWidget *window;
  GtkWidget *img;
} gWidgets;

/***************************************************************** PROTOTYPES */
static void activate(GtkApplication *app, gpointer user_data);
static void imgCallback(GtkWidget *widget, GdkEvent *event, gpointer user_data);

/************************************************************* IMAGE CALLBACK */
static void
imgCallback(GtkWidget *widget, GdkEvent *event, gpointer user_data)
{
  GtkWidget *dialog;
  GtkFileFilter *filter;
  gint res;
  gWidgets *w = (gWidgets *)user_data;

  filter = gtk_file_filter_new();
  dialog = gtk_file_chooser_dialog_new("Open File",
                                       GTK_WINDOW(w->window),
                                       GTK_FILE_CHOOSER_ACTION_OPEN,
                                       "_Cancel",
                                       GTK_RESPONSE_CANCEL,
                                       "_Open",
                                       GTK_RESPONSE_ACCEPT,
                                       NULL);
  gtk_file_filter_add_mime_type(GTK_FILE_FILTER(filter), "image/jpg");
  gtk_file_filter_add_mime_type(GTK_FILE_FILTER(filter), "image/png");
  gtk_file_chooser_set_filter(GTK_FILE_CHOOSER(dialog),filter);

  res = gtk_dialog_run (GTK_DIALOG (dialog));
  if (res == GTK_RESPONSE_ACCEPT)
    {
      gchar *filename;
      GtkFileChooser *chooser = GTK_FILE_CHOOSER (dialog);
      filename = gtk_file_chooser_get_filename (chooser);
      gtk_image_set_from_file(GTK_IMAGE(w->img), filename);
      g_free (filename);
    }

  gtk_widget_destroy (dialog);
}

/**************************************************************** MAIN WINDOW */
static void
activate (GtkApplication *app, gpointer user_data)
{
  GtkWidget *box, *fbox, *ebox;
  gWidgets *w = (gWidgets *)user_data;

  /* create a window with title, default size,and icons */
  w->window = gtk_application_window_new(app);
  gtk_window_set_application(GTK_WINDOW(w->window), GTK_APPLICATION (app));
  gtk_window_set_title(GTK_WINDOW(w->window), "Student Management Toolbox");
  gtk_window_set_default_size(GTK_WINDOW(w->window), 500,300);
  gtk_window_set_default_icon_from_file("icon.png", NULL);

  box = gtk_box_new(GTK_ORIENTATION_VERTICAL,2);
  gtk_container_add(GTK_CONTAINER(w->window), GTK_WIDGET(box));

  fbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL,2);
  gtk_box_pack_start(GTK_BOX(box), GTK_WIDGET(fbox), FALSE, TRUE, 2);

  ebox = gtk_event_box_new();
  w->img = gtk_image_new_from_file("src/avatar.png");
  gtk_container_add(GTK_CONTAINER(ebox), w->img);
  gtk_box_pack_start(GTK_BOX(fbox), GTK_WIDGET(ebox), FALSE, TRUE, 2);
  g_signal_connect(G_OBJECT (ebox),"button_press_event",
                   G_CALLBACK (imgCallback), (gpointer)w);

  /* display all widgets */
  gtk_widget_show_all(GTK_WIDGET(w->window));
}

/*********************************************************************** main */
int
main (int argc, char **argv)
{
  GtkApplication *app;
  int status;
  gWidgets *w = g_malloc(sizeof(w));

  app = gtk_application_new ("org.gtk.example",G_APPLICATION_FLAGS_NONE);
  g_signal_connect (app, "activate", G_CALLBACK (activate), (gpointer)w);
  status = g_application_run (G_APPLICATION (app), argc, argv);
  g_object_unref (app);

  g_free(w);
  return status;
}
/** EOF */