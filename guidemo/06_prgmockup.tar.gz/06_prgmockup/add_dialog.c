/**
 * Add dialog for a GNOME/GTK+ Application
 *
 *  M. Horauer
 */
#include "gnomemenu.h"
#include "menucallbacks.h"
#include "listview.h"
#include "add_dialog.h"
#include "listview_helper.h"

/******************************************************************** GLOBALS */
GtkWidget *img;
GtkApplication *app;
GtkWidget *dateDate, *idNbr, *emailAddr;
GtkWidget *gnameEntry, *fnameEntry, *streetEntry, *cityEntry, *zipEntry,
          *phoneEntry, *byearSpin, *bmonthSpin, *bdaySpin;
gchar dateStamp[256];
gchar *year;
gchar id[256] = "";
GtkWidget *dialog;

/*************************************************************** img_callback */
void
img_callback (GtkApplication *app, gpointer user_data)
{
  GtkWidget *imgDialog;
  GtkFileFilter *filter;
  gint res;

  filter = gtk_file_filter_new ();

  imgDialog = gtk_file_chooser_dialog_new("Open File", GTK_WINDOW(dialog),
                                          GTK_FILE_CHOOSER_ACTION_OPEN,
                                          "_Cancel", GTK_RESPONSE_CANCEL,
                                          "_Open", GTK_RESPONSE_ACCEPT, NULL);

  gtk_file_filter_add_mime_type(GTK_FILE_FILTER(filter), "image/jpg");
  gtk_file_filter_add_mime_type(GTK_FILE_FILTER(filter), "image/png");
  gtk_file_chooser_set_filter(GTK_FILE_CHOOSER(imgDialog),filter);

  res = gtk_dialog_run (GTK_DIALOG (imgDialog));
  if (res == GTK_RESPONSE_ACCEPT)
    {
      char *filename, *tfilename;
      char ofilename[256] = "";
      GFile *in, *out;
      GtkWidget *image;
      const GdkPixbuf *pb;
      GError **error = NULL;

      GtkFileChooser *chooser = GTK_FILE_CHOOSER (imgDialog);
      filename = gtk_file_chooser_get_filename (chooser);

      // get size of image
      image = gtk_image_new_from_file(filename);
      pb = gtk_image_get_pixbuf(GTK_IMAGE(image));
      /* if size matches w=80 && h=90 copy it to destination and load it */
      if (gdk_pixbuf_get_width(pb)==80 && gdk_pixbuf_get_height(pb)==90)
      {
        /* remove the path & add a new default one "./img/" where we store all
           images */
        tfilename = g_strrstr(filename,"/");
        g_sprintf(ofilename,"./img/%s",&tfilename[1]);
        /* copy the image */
        in = g_file_new_for_path(filename);
        out = g_file_new_for_path(ofilename);
        g_file_copy(in,out,G_FILE_COPY_NONE,NULL,NULL,NULL,error);
        gtk_image_set_from_file(GTK_IMAGE(img), ofilename);
      }
      else
      {
        gtk_image_set_from_file(GTK_IMAGE(img), "src/avatar2.png");
      }
      g_free (filename);
    }
  gtk_widget_destroy (imgDialog);
}

/******************************************************* clear_entry_callback */
void
clear_entry_callback (void)
{
  g_print("Clear pressed!\n");
  gtk_label_set_label(GTK_LABEL(dateDate),"XXXX-XX-XX");
  gtk_label_set_label(GTK_LABEL(idNbr),"14012345");
  gtk_label_set_label(GTK_LABEL(emailAddr),"muster@example.domain");
  gtk_entry_set_text(GTK_ENTRY(gnameEntry),"");
  gtk_entry_set_text(GTK_ENTRY(fnameEntry),"");
  gtk_entry_set_text(GTK_ENTRY(streetEntry),"");
  gtk_entry_set_text(GTK_ENTRY(cityEntry),"");
  gtk_entry_set_text(GTK_ENTRY(zipEntry),"");
  gtk_entry_set_text(GTK_ENTRY(phoneEntry),"");
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(byearSpin), 1990);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(bmonthSpin), 1);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(bdaySpin), 1);
  gtk_image_set_from_file(GTK_IMAGE(img), "src/avatar.png");
}

/********************************************************* add_entry_callback */
void
add_entry_callback (void)
{
  g_print("Dialog -> Add pressed!\n");
}

/******************************************************** name_entry_callback */
void
name_entry_callback (GtkWidget *widget, gpointer user_data)
{
  gint studyProgNr = 54;
  gchar *org = "uni";
  gchar *cnt = "net";
  gchar *gname, *fname;
  gchar email[256];

  /* construct the eMail address */
  gname = (gchar *)gtk_entry_get_text(GTK_ENTRY(gnameEntry));
  fname = (gchar *)gtk_entry_get_text(GTK_ENTRY(fnameEntry));
  /* we update the fields on the top only when we got a family name */
  if ((g_strcmp0(gname,"")!=0) && (g_strcmp0(fname,"")!=0))
  {
    g_sprintf(email,"%s.%s@%s.%s",gname,fname,org,cnt);
    gtk_label_set_label(GTK_LABEL(emailAddr),email);
    /* update date info when Family Name was entered */
    get_datestamp(dateStamp);
    gtk_label_set_label(GTK_LABEL(dateDate),dateStamp);
    /* construct student id when Family Name was entered */
    year = g_strndup(dateStamp,4);
    g_snprintf(id,10,"%s%d%03d",year,studyProgNr,get_next_id());
    gtk_label_set_label(GTK_LABEL(idNbr),id);
  }
}

/**************************************************************** add_dioalog */
void
add_dialog (gchar *message)
{
  GtkWidget *box;
  GtkWidget *ebox;
  GtkWidget *grid;
  GtkWidget *photoLabel, *dateLabel, *idLabel, *emailLabel;
  GtkWidget *gnameLabel, *fnameLabel, *streetLabel, *cityLabel, *zipLabel,
            *phoneLabel;
  GtkWidget *birthLabel;
  GtkWidget *add_button, *cancel_button;
  GtkStyleContext *context;

  GtkWidget *content_area;
  gint result;

  dialog = gtk_dialog_new_with_buttons ("Add Student", GTK_WINDOW(window),
                                        GTK_DIALOG_MODAL |
                                        GTK_DIALOG_DESTROY_WITH_PARENT |
                                        GTK_DIALOG_USE_HEADER_BAR,
                                        GTK_BUTTONS_NONE,
                                        NULL);

  add_button = gtk_dialog_add_button (GTK_DIALOG(dialog), "_Add",
                                      GTK_RESPONSE_ACCEPT);
  cancel_button = gtk_dialog_add_button(GTK_DIALOG(dialog), "_Cancel",
                                        GTK_RESPONSE_CANCEL);
  context = gtk_widget_get_style_context(add_button);
  gtk_style_context_add_class (context, "text-button");
  gtk_style_context_add_class(context, "suggested-action");
  context = gtk_widget_get_style_context(cancel_button);
  gtk_style_context_add_class (context, "text-button");
  gtk_style_context_add_class(context, "destructive-action");


  content_area = gtk_dialog_get_content_area (GTK_DIALOG (dialog));
  /* Create the widgets */
  box = gtk_box_new(GTK_ORIENTATION_VERTICAL,0);
  gtk_box_pack_start (GTK_BOX (content_area), box, TRUE, TRUE, 0);
  /* grid: image and labels */
  grid = gtk_grid_new();
  gtk_grid_set_column_spacing(GTK_GRID(grid),5);
  gtk_grid_set_row_spacing(GTK_GRID(grid),5);
  gtk_widget_set_size_request(GTK_WIDGET(grid),400,90);
  gtk_widget_set_valign(GTK_WIDGET(grid),GTK_ALIGN_CENTER);
  gtk_widget_set_halign(GTK_WIDGET(grid),GTK_ALIGN_CENTER);
  gtk_box_pack_start(GTK_BOX(box), GTK_WIDGET(grid), TRUE, TRUE, 0);

  /* clickable image top left */
  photoLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "Photo:", "xalign", 1.0,
                             "yalign", 0.5, NULL);
  gtk_widget_set_size_request(GTK_WIDGET(photoLabel),80,30);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(photoLabel),0,0,1,1);
  ebox = gtk_event_box_new();
  gtk_widget_set_size_request(GTK_WIDGET(ebox),150,90);
  gtk_widget_set_valign(GTK_WIDGET(ebox),GTK_ALIGN_CENTER);
  gtk_widget_set_halign(GTK_WIDGET(ebox),GTK_ALIGN_CENTER);
  img = gtk_image_new_from_file("src/avatar.png");
  gtk_widget_set_tooltip_text(GTK_WIDGET(img),
    "Click to add an image!\nImage size must be 80x90 pixels!");
  gtk_container_add (GTK_CONTAINER(ebox), img);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(ebox),1,0,1,3);
  g_signal_connect (G_OBJECT (ebox),"button_press_event",
                    G_CALLBACK (img_callback),NULL);

  dateLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "Date:", "xalign", 1.0,
                             "yalign", 0.5, NULL);
  gtk_widget_set_size_request(GTK_WIDGET(dateLabel),150,30);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(dateLabel),2,0,1,1);
  dateDate = gtk_widget_new(GTK_TYPE_LABEL, "label", "XXXX-XX-XX",
                            "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_widget_set_size_request(GTK_WIDGET(dateDate),150,30);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(dateDate),3,0,1,1);

  idLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "Student ID:",
                           "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(idLabel),2,1,1,1);
  idNbr = gtk_widget_new(GTK_TYPE_LABEL, "label", "201412345",
                         "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(idNbr),3,1,1,1);

  emailLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "eMail:",
                              "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(emailLabel),2,2,1,1);
  emailAddr = gtk_widget_new(GTK_TYPE_LABEL, "label", "tom.bone@uni.edu",
                             "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(emailAddr),3,2,1,1);

  gnameLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "Given Name:",
                              "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(gnameLabel),0,3,1,1);
  gnameEntry = gtk_entry_new();
  gtk_entry_set_placeholder_text(GTK_ENTRY(gnameEntry), "Eva");
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(gnameEntry),1,3,1,1);

  fnameLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "Family Name:",
                              "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(fnameLabel),2,3,1,1);
  fnameEntry = gtk_entry_new();
  gtk_entry_set_placeholder_text(GTK_ENTRY(fnameEntry), "Muster");
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(fnameEntry),3,3,1,1);
  /* UNUSUAL: we trigger the nameEntryCB() when fnameEntry changes state */
  g_signal_connect(G_OBJECT(fnameEntry), "state-flags-changed",
                   G_CALLBACK(name_entry_callback), NULL);
  streetLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "Street:",
                               "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(streetLabel),0,4,1,1);
  streetEntry = gtk_entry_new();
  gtk_entry_set_placeholder_text(GTK_ENTRY(streetEntry), "Backstreet 42");
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(streetEntry),1,4,1,1);

  cityLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "City:",
                             "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(cityLabel),2,4,1,1);
  cityEntry = gtk_entry_new();
  gtk_entry_set_placeholder_text(GTK_ENTRY(cityEntry), "Hometown");
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(cityEntry),3,4,1,1);

  zipLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "ZIP Code:",
                            "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(zipLabel),0,5,1,1);
  zipEntry = gtk_entry_new();
  gtk_entry_set_placeholder_text(GTK_ENTRY(zipEntry), "A-1234");
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(zipEntry),1,5,1,1);

  phoneLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "Phone:",
                              "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(phoneLabel),2,5,1,1);
  phoneEntry = gtk_entry_new();
  gtk_entry_set_placeholder_text(GTK_ENTRY(phoneEntry), "+43(1)1234567");
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(phoneEntry),3,5,1,1);

  birthLabel = gtk_widget_new(GTK_TYPE_LABEL, "label", "Date of Birth:",
                              "xalign", 1.0, "yalign", 0.5, NULL);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(birthLabel),0,6,1,1);
  byearSpin = gtk_spin_button_new_with_range(1900,2000,1);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(byearSpin), 1990);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(byearSpin),1,6,1,1);
  bmonthSpin = gtk_spin_button_new_with_range(1,12,1);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(bmonthSpin),2,6,1,1);
  bdaySpin = gtk_spin_button_new_with_range(1,31,1);
  gtk_grid_attach(GTK_GRID(grid),GTK_WIDGET(bdaySpin),3,6,1,1);

  gtk_widget_show_all(box);

  result = gtk_dialog_run(GTK_DIALOG (dialog));
  if (result == GTK_RESPONSE_ACCEPT)
    add_entry_callback();
  gtk_widget_destroy (dialog);
}
/*! EOF */