/**
 * Listview GNOME/GTK+ Application
 *
 * M. Horauer
 */
#include "gnomemenu.h"
#include "menucallbacks.h"
#include "listview.h"
#include "add_dialog.h"

/******************************************************************** GLOBALS */
GtkTreeModel *model = NULL;

student data[] = {
  {FALSE, "2014-05-18", "201454001", "john.hombre@uni.edu", "Hombre", "John",
   "WestWay 1", "FortW", "U-123", "0100112233", 1980, 1, 1},
  {FALSE, "2014-05-19", "201454002", "tom.ranger@uni.edu", "Ranger", "Tom",
   "Wigwam 1", "Apache", "U-007", "0100663366", 1985, 6, 6},
  {FALSE, "2014-05-19", "201454003", "lustiger.fuchs@uni.edu", "Fuchs",
   "Lustiger", "Wigwam 00", "Apache", "U-007", "0100660066", 1980, 12, 12},
  {FALSE, "2014-05-20", "201454004", "uschi.wilde@uni.edu", "Wilde", "Uschi",
   "Wigwam 6", "Apache", "U-007", "0166666666", 1999, 9, 9},
  {FALSE, "2014-05-20", "201454005", "alter.wolf@uni.edu", "Wolf", "Alter",
   "Wigwam 9", "Apache", "U-007", "0133445566", 1988, 8, 8},};

/********************************************************** TreeView Callback */
void
select_callback (GtkCellRendererToggle *cell, gchar *path_str, gpointer data)
{
  GtkTreeModel *model = (GtkTreeModel *)data;
  GtkTreeIter  iter;
  GtkTreePath *path = gtk_tree_path_new_from_string (path_str);
  gboolean fixed;

  /* get toggled iter */
  gtk_tree_model_get_iter (model, &iter, path);
  gtk_tree_model_get (model, &iter, COLUMN_FIXED, &fixed, -1);

  /* do something with the value */
  fixed ^= 1;

  g_print("Item Clicked ...\n");

  /* set new value */
  gtk_list_store_set (GTK_LIST_STORE (model), &iter, COLUMN_FIXED, fixed, -1);

  /* clean up */
  gtk_tree_path_free (path);
}


GtkTreeModel *
create_model (void)
{
  gint i = 0;
  GtkListStore *store;
  GtkTreeIter iter;

  /* create list store */
  store = gtk_list_store_new (NUM_COLUMNS,
                              G_TYPE_BOOLEAN,
                              G_TYPE_STRING,   /* inDate */
                              G_TYPE_STRING,   /* iD */
                              G_TYPE_STRING,   /* email */
                              G_TYPE_STRING,   /* givenName */
                              G_TYPE_STRING,   /* familyName */
                              G_TYPE_STRING,   /* street */
                              G_TYPE_STRING,   /* city */
                              G_TYPE_STRING,   /* zipCode */
                              G_TYPE_STRING,   /* phone */
                              G_TYPE_UINT,     /* bYear */
                              G_TYPE_UINT,     /* bMonth */
                              G_TYPE_UINT);    /* bDay */

  /* add data to the list store */
  for (i = 0; i < G_N_ELEMENTS (data); i++)
  {
    gtk_list_store_append (store, &iter);
    gtk_list_store_set (store, &iter,
                        COLUMN_FIXED, data[i].fixed,
                        COLUMN_DATE, data[i].inDate,
                        COLUMN_ID, data[i].iD,
                        COLUMN_EMAIL, data[i].email,
                        COLUMN_GNAME, data[i].givenName,
                        COLUMN_FNAME, data[i].familyName,
                        COLUMN_STREET, data[i].street,
                        COLUMN_CITY, data[i].city,
                        COLUMN_ZIP, data[i].zipCode,
                        COLUMN_PHONE, data[i].phone,
                        COLUMN_YEAR, data[i].bYear,
                        COLUMN_MONTH, data[i].bMonth,
                        COLUMN_DAY, data[i].bDay,
                        -1);
  }
  return GTK_TREE_MODEL (store);
}


void
add_columns (GtkTreeView *treeview)
{
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeModel *model = gtk_tree_view_get_model (treeview);

  /* column for fixed toggles */
  renderer = gtk_cell_renderer_toggle_new ();
  g_signal_connect (renderer, "toggled",
                    G_CALLBACK (select_callback), model);

  column = gtk_tree_view_column_new_with_attributes ("Select",
           renderer,
           "active", COLUMN_FIXED,
           NULL);
  gtk_tree_view_append_column (treeview, column);

  /* column for inscription date */
  renderer = gtk_cell_renderer_text_new ();
  column = gtk_tree_view_column_new_with_attributes ("Date",
           renderer,
           "text",
           COLUMN_DATE,
           NULL);
  gtk_tree_view_column_set_sort_column_id (column, COLUMN_DATE);
  gtk_tree_view_append_column (treeview, column);

  /* column for iD */
  renderer = gtk_cell_renderer_text_new ();
  column = gtk_tree_view_column_new_with_attributes ("ID",
           renderer,
           "text",
           COLUMN_ID,
           NULL);
  gtk_tree_view_column_set_sort_column_id (column, COLUMN_ID);
  gtk_tree_view_append_column (treeview, column);

  /* column for email */
  renderer = gtk_cell_renderer_text_new ();
  column = gtk_tree_view_column_new_with_attributes ("eMail",
           renderer,
           "text",
           COLUMN_EMAIL,
           NULL);
  gtk_tree_view_column_set_sort_column_id (column, COLUMN_EMAIL);
  gtk_tree_view_append_column (treeview, column);

  /* column for givenName */
  renderer = gtk_cell_renderer_text_new ();
  column = gtk_tree_view_column_new_with_attributes ("Given Name",
           renderer,
           "text",
           COLUMN_GNAME,
           NULL);
  gtk_tree_view_column_set_sort_column_id (column, COLUMN_GNAME);
  gtk_tree_view_append_column (treeview, column);

  /* column for familyName */
  renderer = gtk_cell_renderer_text_new ();
  column = gtk_tree_view_column_new_with_attributes ("Family Name",
           renderer,
           "text",
           COLUMN_FNAME,
           NULL);
  gtk_tree_view_column_set_sort_column_id (column, COLUMN_FNAME);
  gtk_tree_view_append_column (treeview, column);

  /* column for street */
  renderer = gtk_cell_renderer_text_new ();
  column = gtk_tree_view_column_new_with_attributes ("Address",
           renderer,
           "text",
           COLUMN_STREET,
           NULL);
  gtk_tree_view_column_set_sort_column_id (column, COLUMN_STREET);
  gtk_tree_view_append_column (treeview, column);

  /* column for city */
  renderer = gtk_cell_renderer_text_new ();
  column = gtk_tree_view_column_new_with_attributes ("City",
           renderer,
           "text",
           COLUMN_CITY,
           NULL);
  gtk_tree_view_column_set_sort_column_id (column, COLUMN_CITY);
  gtk_tree_view_append_column (treeview, column);

  /* column for zipCode */
  renderer = gtk_cell_renderer_text_new ();
  column = gtk_tree_view_column_new_with_attributes ("ZIP",
           renderer,
           "text",
           COLUMN_ZIP,
           NULL);
  gtk_tree_view_column_set_sort_column_id (column, COLUMN_ZIP);
  gtk_tree_view_append_column (treeview, column);

  /* column for phone */
  renderer = gtk_cell_renderer_text_new ();
  column = gtk_tree_view_column_new_with_attributes ("Phone",
           renderer,
           "text",
           COLUMN_PHONE,
           NULL);
  gtk_tree_view_column_set_sort_column_id (column, COLUMN_PHONE);
  gtk_tree_view_append_column (treeview, column);

  /* column for bYear */
  renderer = gtk_cell_renderer_text_new ();
  column = gtk_tree_view_column_new_with_attributes ("Year",
           renderer,
           "text",
           COLUMN_YEAR,
           NULL);
  gtk_tree_view_column_set_sort_column_id (column, COLUMN_YEAR);
  gtk_tree_view_append_column (treeview, column);

  /* column for bMonth */
  renderer = gtk_cell_renderer_text_new ();
  column = gtk_tree_view_column_new_with_attributes ("Month",
           renderer,
           "text",
           COLUMN_MONTH,
           NULL);
  gtk_tree_view_column_set_sort_column_id (column, COLUMN_MONTH);
  gtk_tree_view_append_column (treeview, column);

  /* column for bDay */
  renderer = gtk_cell_renderer_text_new ();
  column = gtk_tree_view_column_new_with_attributes ("Day",
           renderer,
           "text",
           COLUMN_DAY,
           NULL);
  gtk_tree_view_column_set_sort_column_id (column, COLUMN_DAY);
  gtk_tree_view_append_column (treeview, column);
}
/** EOF */